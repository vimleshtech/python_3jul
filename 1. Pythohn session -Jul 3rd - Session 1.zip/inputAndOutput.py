rno = input('enter rno :')
name                                         = input('enter name :')
hs  = input('enter score in hindi :')
es  = input('enter score in english :')
cs  = input('enter score in cmputer sc.:')
ms  = input('enter score in maths. :')

#print(type(hs))

total = int( hs) + int(es) + int(cs)+int(ms)
avg = total/4

print('total score is :',total)
print('average score is :',avg)

if avg>=80:
     print('Grade A')
     
elif avg>=60:
     print('Greade B')
elif avg>=50:
     print('Grade C')
else:
     print('Greade D')
     
     

     

     
