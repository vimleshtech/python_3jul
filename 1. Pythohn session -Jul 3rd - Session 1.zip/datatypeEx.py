a =111  # int 
print(type(a))


a =111.33  # float
print(type(a))


a ='a111'  # str
print(type(a))


a ="111"  # str
print(type(a))

a =False  # bool
print(type(a))

a = [333,4,333] #list
print(type(a))


a = (333,4,333) #tuple
print(type(a))

a ={'a':'alpha','b':'beta'}#dict
print(type(a))

a ={'dove','lux','sony phone','dove'}#set
print(type(a))



