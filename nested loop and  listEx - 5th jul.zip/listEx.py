data = [11,2,3,4333,4]

print(max(data))
print(min(data))
print(sum(data))
print(len(data))

data.sort()
print(data)

data.append(111)
print(data)

data.pop()
print(data)

data.insert(2,3344)
print(data)

data.remove(2)
print(data)
